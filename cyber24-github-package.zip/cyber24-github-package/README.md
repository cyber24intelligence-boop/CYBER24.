# CYBER24 GitHub Package

Complete scaffold for the CYBER24 GitHub ecosystem. Start with
[PUBLISHING_GUIDE.md](PUBLISHING_GUIDE.md).

## Contents

| Path | What it is |
| --- | --- |
| `PUBLISHING_GUIDE.md` | Step-by-step publishing instructions |
| `profile-readme/README.md` | Your personal GitHub profile README |
| `repos/.github/` | Organization profile, defaults, templates, labels, milestones, board guidance |
| `repos/cyber24-core/` | Shared foundation (Python) |
| `repos/cyber24-ai-research/` | AI research workspace (Python) |
| `repos/cyber24-security/` | Defensive security engineering (Python) |
| `repos/cyber24-threat-intelligence/` | Threat-intelligence schemas and methods (Python) |
| `repos/cyber24-cloud/` | Cloud security guidance |
| `repos/cyber24-docs/` | Documentation, policies, brand |
| `scripts/` | Publishing, label, milestone, and placeholder scripts |

## Placeholders to replace

- `YOUR-GITHUB-USERNAME`: your GitHub username.
- `security@YOUR-DOMAIN.example`: a real security contact address.
- The organization name `CYBER24` if GitHub says it is taken.

`scripts/replace-placeholders.sh` does this for you.

## Honesty note

Every repository is a scaffold. The only tested code is a package smoke test
in each Python repository and a schema test in `cyber24-threat-intelligence`.
No product features are implemented or claimed.
