# Publishing Guide

Allow 30 to 45 minutes. Do the steps in order.

## 0. Prerequisites

- A GitHub account with two-factor authentication enabled.
- [Git](https://git-scm.com/downloads) installed.
- Optional but recommended: [GitHub CLI](https://cli.github.com/) (`gh`) and `jq`.
- Unzip this package to a folder.

## 1. Replace placeholders

```bash
cd cyber24-github-package
./scripts/replace-placeholders.sh YOUR_USERNAME you@yourdomain.com
```

Use a real security contact address. If the name `CYBER24` is taken in step 2,
pass your chosen organization name as a third argument.

## 2. Create the organization

1. Go to <https://github.com/account/organizations/new> and choose the free plan.
2. Name it `CYBER24`, or the closest available name.
3. Set the organization profile (name, description, URL, location) from the
   organization **Settings** page. Suggested description: "Intelligent
   Technology. Security-Driven Innovation."
4. Under **Settings > Authentication security**, require two-factor authentication.

## 3. Publish the repositories

Automatic (with `gh`):

```bash
gh auth login
./scripts/publish.sh CYBER24 private
```

Create them as `private` first, review everything, then make them public
under each repository's **Settings > Danger Zone > Change visibility**.

Manual: create each empty repository on GitHub (no README, no .gitignore), then in each folder under
`repos/`:

```bash
git init -b main
git add -A
git commit -m "chore: initial scaffold"
git remote add origin https://github.com/CYBER24/REPO_NAME.git
git push -u origin main
```

The seven repositories are `.github`, `cyber24-core`, `cyber24-ai-research`,
`cyber24-security`, `cyber24-threat-intelligence`, `cyber24-cloud`, and
`cyber24-docs`.

## 4. Organization profile page

The file `profile/README.md` in the `.github` repository is displayed on the
organization page. It only appears publicly when the `.github` repository is
public. Make that repository public once reviewed.

## 5. Personal profile README

1. Create a **public** repository named exactly your username (for example
   `YOUR_USERNAME/YOUR_USERNAME`).
2. Copy `profile-readme/README.md` into it as `README.md` and push.
3. Pin the CYBER24 repositories on your profile.

## 6. Labels and milestones

```bash
./scripts/apply-labels.sh CYBER24
./scripts/create-milestones.sh CYBER24
```

(Requires `gh` and `jq`.)

## 7. Repository settings (each repository)

Under **Settings**:

- **Code security**: enable Dependency graph, Dependabot alerts, Dependabot
  security updates, Secret scanning, Push protection, and **Private
  vulnerability reporting**. Some features need a public repository or a paid
  plan on private ones.
- **Branches**: add a protection rule for `main` requiring pull requests, at
  least one approval, and passing status checks (`Repository quality`,
  `Markdown lint`, `YAML lint`, and the Python job where present). Check the
  exact names after the first CI run. As sole maintainer, you may initially
  skip the approval requirement.
- **General**: enable Issues and Discussions; enable "Automatically delete head branches".
- **Actions > General**: set workflow permissions to **Read repository
  contents** and leave "Allow GitHub Actions to create and approve pull
  requests" off.

## 8. Project board

Follow `repos/.github/project-management/project-boards.md` to create the
organization project.

## 9. Check CI

Open the **Actions** tab of each repository and confirm the CI run is green.
If a run fails, read the log; the most common cause is a Markdown lint rule.

## 10. Choose a license

No license is included on purpose, so all rights stay reserved. Before you
accept outside contributions, choose one (for example MIT or Apache-2.0) at
<https://choosealicense.com>, add a `LICENSE` file, and update each README.

## 11. Replace the wordmark when ready

`cyber24-docs/brand/` contains simple text wordmarks. Commission or design a
proper logo when you can, and upload it as the organization avatar.

## Reminders

- Keep claims honest: do not describe features as available until they are implemented and tested.
- Do not add team members to the README until they have actually joined.
- Never commit secrets. Rotate any credential that is ever pushed by mistake.
