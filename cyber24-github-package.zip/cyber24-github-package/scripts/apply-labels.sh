#!/usr/bin/env bash
set -euo pipefail

# Usage: scripts/apply-labels.sh <org>   (requires gh and jq)
ORG="${1:?Usage: apply-labels.sh <org>}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/repos/.github/project-management/labels.json"

for repo in cyber24-core cyber24-ai-research cyber24-security \
            cyber24-threat-intelligence cyber24-cloud cyber24-docs; do
  echo "==> labels for $repo"
  jq -c '.[]' "$FILE" | while read -r l; do
    gh label create "$(jq -r .name <<<"$l")" \
      --color "$(jq -r .color <<<"$l")" \
      --description "$(jq -r .description <<<"$l")" \
      --repo "$ORG/$repo" --force
  done
done
