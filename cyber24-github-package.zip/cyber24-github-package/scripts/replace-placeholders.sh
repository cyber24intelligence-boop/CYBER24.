#!/usr/bin/env bash
set -euo pipefail

# Usage: scripts/replace-placeholders.sh <github-username> <security-email> [org-name]
# Replaces the placeholder values across the whole package.
USER_NAME="${1:?github username}"
EMAIL="${2:?security contact email}"
NEW_ORG="${3:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

grep -rlI --exclude-dir=.git -e 'YOUR-GITHUB-USERNAME' -e 'security@YOUR-DOMAIN.example' "$ROOT" |
  while read -r f; do
    sed -i.bak -e "s#YOUR-GITHUB-USERNAME#$USER_NAME#g" -e "s#security@YOUR-DOMAIN.example#$EMAIL#g" "$f"
    rm -f "$f.bak"
  done

if [ -n "$NEW_ORG" ] && [ "$NEW_ORG" != "CYBER24" ]; then
  grep -rlI --exclude-dir=.git -e 'github.com/CYBER24' "$ROOT" |
    while read -r f; do
      sed -i.bak "s#github.com/CYBER24#github.com/$NEW_ORG#g" "$f"
      rm -f "$f.bak"
    done
fi
echo "Placeholders replaced."
