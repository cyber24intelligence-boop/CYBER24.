#!/usr/bin/env bash
set -euo pipefail

# Usage: scripts/create-milestones.sh <org>   (requires gh and jq)
ORG="${1:?Usage: create-milestones.sh <org>}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/repos/.github/project-management/milestones.json"

for repo in cyber24-core cyber24-ai-research cyber24-security \
            cyber24-threat-intelligence cyber24-cloud cyber24-docs; do
  echo "==> milestones for $repo"
  jq -c '.[]' "$FILE" | while read -r m; do
    gh api "repos/$ORG/$repo/milestones" \
      -f title="$(jq -r .title <<<"$m")" \
      -f description="$(jq -r .description <<<"$m")" >/dev/null || echo "   (exists or failed: $(jq -r .title <<<"$m"))"
  done
done
