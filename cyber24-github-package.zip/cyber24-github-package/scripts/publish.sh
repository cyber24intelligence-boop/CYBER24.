#!/usr/bin/env bash
set -euo pipefail

# Usage: scripts/publish.sh <org> [private|public]
# Requires: git, GitHub CLI (gh) authenticated with: gh auth login
ORG="${1:?Usage: publish.sh <org> [private|public]}"
VIS="${2:-private}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

for repo in .github cyber24-core cyber24-ai-research cyber24-security \
            cyber24-threat-intelligence cyber24-cloud cyber24-docs; do
  echo "==> $repo ($VIS)"
  cd "$ROOT/repos/$repo"
  [ -d .git ] || git init -q -b main
  git add -A
  git commit -q -m "chore: initial scaffold" || true
  gh repo create "$ORG/$repo" "--$VIS" --source=. --remote=origin --push
done
echo "Done. Next: run scripts/apply-labels.sh and scripts/create-milestones.sh"
