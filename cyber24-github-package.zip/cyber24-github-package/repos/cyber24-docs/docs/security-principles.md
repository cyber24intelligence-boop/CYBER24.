# Security Principles

1. **Least privilege.** Grant the minimum access required, for people and automation. CI tokens are read-only by default.
2. **Defence in depth.** Do not rely on a single control.
3. **Secure by default.** Safe configuration is the default; unsafe options require explicit action.
4. **No secrets in Git.** Credentials, tokens, and keys never enter the repository. Use secret managers and GitHub encrypted secrets only where unavoidable.
5. **Minimise attack surface.** Keep dependencies few and reviewed.
6. **Protect the supply chain.** Pin and update dependencies, review automation, and keep Dependabot enabled.
7. **Threat-model changes.** Consider how a feature could be abused.
8. **Fail safely.** Errors must not expose data or weaken controls.
9. **Verify, do not assume.** Test security-relevant behaviour; do not claim protection that has not been tested.
10. **Transparency.** Handle vulnerabilities through coordinated disclosure and document fixes.

## Repository hygiene

- Enable two-factor authentication for every account with access.
- Enable branch protection on `main`, secret scanning, push protection, and private vulnerability reporting.
- Review third-party GitHub Actions before adopting them.
