# Documentation Index

| Document | Description |
| --- | --- |
| [Overview](overview.md) | What CYBER24 is and its current status |
| [Mission and vision](mission-vision.md) | Purpose and values |
| [Divisions](divisions.md) | Six divisions and responsibilities |
| [Architecture](architecture.md) | Intended structure |
| [Roadmap](roadmap.md) | Planned phases |
| [Technology stack](technology-stack.md) | Initial tooling choices |
| [Research strategy](research-strategy.md) | How research is conducted |
| [Acceptable use](acceptable-use.md) | Ethical and acceptable-use policy |
| [Security principles](security-principles.md) | Engineering security principles |
