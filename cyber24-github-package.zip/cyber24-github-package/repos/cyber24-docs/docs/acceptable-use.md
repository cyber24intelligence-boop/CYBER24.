# Ethical and Acceptable-Use Policy

CYBER24 exists to support defence and legitimate research. This policy applies
to all contributors and to all code, data, and documents in CYBER24
repositories.

## Permitted

- Defensive security engineering, detection, and hardening.
- Security research on systems you own or have explicit written permission to assess.
- Analysis of lawfully obtained threat information.
- Education and documentation that improve defence.

## Prohibited

- Unauthorised access to, or disruption of, any system.
- Developing, distributing, or deploying malware, ransomware, or weaponised exploits.
- Credential theft, phishing kits, stalkerware, or surveillance of individuals.
- Collecting or publishing personal data without a lawful basis.
- Evading security controls on systems without authorisation.
- Using CYBER24 resources to harass, deceive, or harm others.

## Responsible disclosure

If you find a vulnerability in third-party software, report it to the vendor
through their disclosure process. If you find one in CYBER24, follow the
repository security policy.

## AI ethics

- Assess misuse potential before building or releasing capabilities.
- Be transparent about model limits, data sources, and known failure modes.
- Do not present AI-generated output as verified fact without verification.
- Respect privacy and applicable law in all data use.

## Honest claims

Do not describe unimplemented or untested features as existing.

## Enforcement

Maintainers may reject contributions, remove content, and restrict
participation for violations. Serious violations may be reported to the
appropriate authorities.

## Disclaimer

This document is a project policy, not legal advice. Consult a qualified
lawyer about legal obligations in your jurisdiction.
