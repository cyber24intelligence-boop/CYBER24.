# Project Overview

CYBER24 is an early-stage technology initiative in artificial intelligence and
cybersecurity, founded and led by Rishan. Its tagline is "Intelligent Technology. Security-Driven Innovation."

## What CYBER24 is

An effort to research and build defensive, security-driven technology, organised
into six divisions: AI Research, Security Engineering, Threat Intelligence,
Cloud Security, Software Engineering, and Research & Documentation.

## Current status

- Stage: early-stage development.
- Team: founder-led. No division has additional assigned members yet.
- Software: repositories are scaffolds. Features are not claimed until they are
  implemented and tested.

See [status and honesty policy](#documentation-honesty) below.

## Documentation honesty

Every statement in CYBER24 documentation must describe something that is true
today, or be clearly labelled as planned. Roadmap items are intentions, not
commitments.

## Where to go next

- [Mission and vision](mission-vision.md)
- [Architecture](architecture.md)
- [Divisions](divisions.md)
- [Roadmap](roadmap.md)
- [Technology stack](technology-stack.md)
- [Research strategy](research-strategy.md)
- [Acceptable use](acceptable-use.md)
- [Security principles](security-principles.md)
