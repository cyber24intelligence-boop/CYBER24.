# Mission and Vision

## Mission

To research and build intelligent, security-driven technology that helps
defenders, with rigorous engineering, honest reporting, and responsible
practice.

## Vision

A trusted enterprise-grade technology organisation where artificial
intelligence and security engineering reinforce each other, and where every
claim is backed by tested work.

## Values

- **Security by design.** Security is a requirement from the first commit.
- **Intellectual honesty.** Report limits and negative results as plainly as successes.
- **Defensive purpose.** Build to protect, never to harm.
- **Craftsmanship.** Small, tested, documented, maintainable.
- **Responsibility.** Consider misuse and privacy before publishing.
