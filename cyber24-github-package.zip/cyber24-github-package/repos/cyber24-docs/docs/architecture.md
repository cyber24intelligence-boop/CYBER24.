# Architecture

This document describes the intended structure. It is a design intent for an
early-stage project, not a description of shipped software.

## Principles

- **Modular.** Each division owns a repository with clear boundaries.
- **Layered.** Shared foundations live in `cyber24-core`; specialised work lives in division repositories.
- **Testable.** Every module has tests that run in CI.
- **Documented.** Decisions are recorded as architecture decision records (ADRs).
- **Secure by default.** No secrets in code, least-privilege automation.

## Repository map

| Repository | Role |
| --- | --- |
| `cyber24-core` | Shared libraries, application scaffolding, prototypes |
| `cyber24-ai-research` | AI research and evaluation |
| `cyber24-security` | Defensive security engineering |
| `cyber24-threat-intelligence` | Threat data schemas, methods, and templates |
| `cyber24-cloud` | Cloud security guidance and benchmarks |
| `cyber24-docs` | Central documentation and brand |
| `.github` | Organization profile, defaults, and workflow templates |

## Dependency direction

```mermaid
flowchart TD
    AI[cyber24-ai-research] --> CORE[cyber24-core]
    SEC[cyber24-security] --> CORE
    TI[cyber24-threat-intelligence] --> CORE
    CLOUD[cyber24-cloud] -.documents.-> SEC
    DOCS[cyber24-docs] -.documents.-> CORE
```

Currently no repository imports another; the diagram shows the intended
direction only. Cross-repository dependencies will be introduced deliberately
and recorded in an ADR.

## Environments

Local development and GitHub Actions CI only. No hosted environments exist.
