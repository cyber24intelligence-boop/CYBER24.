# Organization Roadmap

Planned phases. Nothing here is a commitment, and nothing is complete until implemented, tested, and merged.

## Phase 0 - Foundation

Status: Planned

- [ ] Publish organization and repositories
- [ ] Establish CI, policies, and documentation baseline

## Phase 1 - Architecture and research baseline

Status: Planned

- [ ] Record architecture decisions
- [ ] Select first research questions
- [ ] Define evaluation and testing standards

## Phase 2 - First prototypes

Status: Planned

- [ ] One narrow, tested prototype per active division
- [ ] Internal review

## Phase 3 - Preview

Status: Planned

- [ ] Security review
- [ ] First pre-release of selected components
- [ ] Gather external feedback
