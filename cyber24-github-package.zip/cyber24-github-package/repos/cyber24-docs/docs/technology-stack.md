# Technology Stack

These are initial choices for the scaffold. They are expected to change as the
project learns.

| Area | Choice | Notes |
| --- | --- | --- |
| Primary language | Python 3.11+ | Research and security tooling |
| Packaging | `pyproject.toml` with setuptools | Standard, minimal |
| Testing | pytest | Run in CI on Python 3.11 and 3.12 |
| Lint and format | ruff | Lint and format check in CI |
| Documentation | Markdown, markdownlint | Linted in CI |
| Configuration files | YAML, yamllint | Linted in CI |
| CI | GitHub Actions | Read-only token, no secrets |
| Dependency updates | Dependabot | GitHub Actions and pip |
| Diagrams | Mermaid | Rendered natively by GitHub |

## Under evaluation

Not decided: infrastructure-as-code tooling, policy-as-code framework, ML
framework, and data-versioning approach. Each will be chosen through an ADR.
