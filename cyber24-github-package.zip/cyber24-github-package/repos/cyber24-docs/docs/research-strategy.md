# Research Strategy

## Approach

1. **Question first.** Each project begins with a written research proposal.
2. **Reproducible.** Experiments record data provenance, versions, and method so another person can repeat them.
3. **Evaluated honestly.** Define the evaluation before running the experiment; report negative and inconclusive results.
4. **Reviewed.** A second reviewer checks results before any claim is made.
5. **Risk-assessed.** Misuse and privacy are assessed before publication.

## Candidate research areas

These are directions under consideration, not active programmes:

- Machine learning for anomaly and threat detection in defensive settings.
- Security and robustness of AI systems, including misuse risks.
- Methods for structuring and assessing threat intelligence.
- Cloud security configuration review and benchmarking.
- Secure software engineering practices.

## Data handling

- Use only data you are licensed and permitted to use.
- Prefer synthetic or public data.
- Never commit personal data, credentials, or real victim data.
- Document provenance and limitations for every dataset.

## Publication

Results are published only after reproduction, review, and a misuse-risk check.
Claims must match the evidence.
