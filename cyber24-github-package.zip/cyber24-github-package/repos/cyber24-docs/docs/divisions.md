# Divisions

CYBER24 is organised into six divisions. Divisions describe areas of responsibility, not existing staff.

## AI Research

Studies how machine learning can support defensive security, and how AI systems themselves can be secured and evaluated.

Responsibilities:

- Survey literature and define research questions.
- Design reproducible experiments and evaluation methods.
- Document findings honestly, including negative results.
- Assess misuse risks before publishing any research output.

**Repository:** [`cyber24-ai-research`](https://github.com/CYBER24/cyber24-ai-research)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.

## Security Engineering

Builds defensive security tooling, hardening guidance, and secure engineering practices.

Responsibilities:

- Design and implement defensive modules with tests.
- Maintain secure-coding and hardening guidance.
- Review code and dependencies for security risk.
- Keep tooling usable only for authorised, defensive work.

**Repository:** [`cyber24-security`](https://github.com/CYBER24/cyber24-security)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.

## Threat Intelligence

Develops methods for collecting, structuring, and analysing threat information from lawful sources.

Responsibilities:

- Define data schemas and source-evaluation criteria.
- Write analysis methods and report templates.
- Apply handling markings and protect privacy.
- Distinguish confirmed facts from assessments in every report.

**Repository:** [`cyber24-threat-intelligence`](https://github.com/CYBER24/cyber24-threat-intelligence)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.

## Cloud Security

Researches and documents secure cloud architecture, configuration, and monitoring.

Responsibilities:

- Maintain vendor-neutral cloud security guidance.
- Develop benchmarks and review checklists.
- Prototype policy-as-code and configuration reviews.
- Track shared-responsibility boundaries per provider.

**Repository:** [`cyber24-cloud`](https://github.com/CYBER24/cyber24-cloud)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.

## Software Engineering

Owns the shared codebase, application scaffolding, testing standards, and CI.

Responsibilities:

- Maintain architecture, code quality, and test strategy.
- Own build, release, and CI/CD workflows.
- Provide shared libraries to other divisions.
- Keep dependencies and supply chain under review.

**Repository:** [`cyber24-core`](https://github.com/CYBER24/cyber24-core)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.

## Research & Documentation

Owns written knowledge: architecture, policies, research strategy, and public documentation.

Responsibilities:

- Keep documentation accurate and in step with the code.
- Maintain architecture decision records.
- Maintain ethical and acceptable-use policies.
- Edit and review research outputs for clarity and honesty.

**Repository:** [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs)

**Staffing:** This division has no assigned members yet. It is currently coordinated by the founder. Roles will be listed here only when real people have accepted them.
