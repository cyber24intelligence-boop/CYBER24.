# Brand Guidelines

## Positioning

Enterprise technology in AI and cybersecurity. Calm, precise, and credible.

Tagline: "Intelligent Technology. Security-Driven Innovation."

## Colour palette

| Name | Hex | Use |
| --- | --- | --- |
| Black | `#0A0A0A` | Primary text and dark backgrounds |
| Graphite | `#2B2B2B` | Secondary surfaces |
| Slate grey | `#5C5C5C` | Secondary text |
| Soft grey | `#8A8A8A` | Borders and subtle accents |
| Light grey | `#EDEDED` | Light surfaces |
| White | `#FFFFFF` | Primary light background |

## Typography

Use a clean sans-serif system stack, for example Inter, Helvetica Neue, or the
system UI font. Use tight, restrained hierarchy. Monospace for code.

## Style rules

- Minimal black-and-white layouts with graphite and grey accents.
- No cartoon graphics, mascots, or decorative effects.
- Generous whitespace and consistent alignment.
- Diagrams in monochrome.

## Logo files

- `cyber24-wordmark-dark.svg`: black wordmark on white.
- `cyber24-wordmark-light.svg`: white wordmark on black.

These are simple text wordmarks created as a starting point. Replace them with
a professionally designed logo when available.
