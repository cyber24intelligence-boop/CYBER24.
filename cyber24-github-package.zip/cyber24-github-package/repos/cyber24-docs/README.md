<div align="center">

# cyber24-docs

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-docs/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-docs/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Central documentation for CYBER24: overview, architecture, policies, research strategy, and brand guidelines.

## In scope

- Project overview, mission, and vision
- Architecture and technology stack
- Ethical and acceptable-use policy
- Security principles and research strategy
- Architecture decision records and brand guidelines

## Out of scope

- Marketing claims about capabilities that are not implemented and tested

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `docs/` | Core documentation set (see index). |
| `adr/` | Architecture decision records. |
| `brand/` | Brand guidelines and logo files. |

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
