# Architecture Decision Records

Record significant decisions here using [the template](0000-template.md). Number records sequentially.
