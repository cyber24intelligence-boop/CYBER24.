# ADR NNNN: Title

- Status: Proposed | Accepted | Superseded
- Date: YYYY-MM-DD

## Context

What problem or decision is being addressed?

## Decision

What was decided?

## Consequences

What becomes easier or harder?
