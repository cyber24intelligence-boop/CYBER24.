# CYBER24 AI Research Roadmap

This roadmap is a statement of intent for an early-stage project. Items are planned, not promised, and may change. Nothing is marked done until it is implemented, tested, and merged.

## Phase 0: Foundation

- [ ] Repository scaffold and CI
- [ ] Research proposal template

## Phase 1: Research baseline

- [ ] Literature review of priority topics
- [ ] Select first research question
- [ ] Define evaluation protocol

## Phase 2: First experiment

- [ ] Implement a reproducible experiment
- [ ] Document dataset provenance and limits
- [ ] Internal review of results

## Phase 3: Publication readiness

- [ ] Misuse-risk assessment
- [ ] Reproducibility check by a second reviewer

## How this roadmap is tracked

Work is tracked through issues, milestones, and the organization project board. See the organization `.github` repository for labels and milestone definitions.
