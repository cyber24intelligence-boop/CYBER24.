<div align="center">

# cyber24-ai-research

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-ai-research/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-ai-research/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Research workspace for applying and securing AI in a cybersecurity context, with emphasis on reproducibility and honest reporting.

## In scope

- Reproducible experiments and evaluation methods
- Literature notes and research proposals
- Security of AI systems (robustness, misuse risk, safe evaluation)
- Documented datasets with licensing and privacy review

## Out of scope

- Training or releasing models intended to cause harm
- Committing model weights or raw datasets to Git
- Publishing unreproduced results as findings

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `pyproject.toml` | Python packaging, test, and lint configuration. |
| `src/cyber24_ai_research/evaluation/` | Evaluation utilities (reserved namespace; empty). |
| `src/cyber24_ai_research/experiments/` | Reusable experiment code (reserved namespace; empty). |
| `research/notes/` | Working research notes. |
| `research/literature/` | Literature reviews and reading notes. |
| `research/proposals/` | Research proposals before work begins. |
| `datasets/` | Dataset documentation only. Data itself is stored outside Git. |
| `models/` | Model cards and documentation. No weights are committed. |
| `notebooks/` | Exploratory notebooks. Clear outputs before committing. |
| `tests/` | Automated tests. |
| `docs/` | Repository documentation. |

## Getting started

Requires Python 3.11 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
