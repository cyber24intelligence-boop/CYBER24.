"""Evaluation utilities (reserved namespace; empty)."""
