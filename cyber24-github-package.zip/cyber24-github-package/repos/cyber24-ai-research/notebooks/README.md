# notebooks

Exploratory notebooks. Clear outputs before committing.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
