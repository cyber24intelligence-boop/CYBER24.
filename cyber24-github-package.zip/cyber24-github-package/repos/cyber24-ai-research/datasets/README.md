# datasets

Dataset **documentation only**. Data files are not stored in Git.

For each dataset, add a `<name>.md` file recording:

- Source and licence (you must be permitted to use it).
- Collection method and date.
- Personal or sensitive data present, and how it was handled.
- Known limitations and biases.
- Where the data is stored and how to obtain it.

Prefer synthetic or public data. Never commit personal data or credentials.
