# proposals

Research proposals before work begins.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
