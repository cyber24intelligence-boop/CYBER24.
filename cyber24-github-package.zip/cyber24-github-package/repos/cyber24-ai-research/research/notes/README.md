# notes

Working research notes.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
