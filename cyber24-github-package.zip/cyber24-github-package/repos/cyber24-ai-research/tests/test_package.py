import cyber24_ai_research


def test_package_exposes_version():
    assert isinstance(cyber24_ai_research.__version__, str)
