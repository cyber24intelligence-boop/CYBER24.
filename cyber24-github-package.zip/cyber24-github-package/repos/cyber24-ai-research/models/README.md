# models

Documentation only. Model weights are not committed to Git.

For each model, add a model card recording intended use, training data,
evaluation method and results, limitations, and misuse risks.
