# detections

Defensive detection logic and authoring guidelines.

## Authoring rules

- Every rule documents what it detects, the data source it needs, and known false positives.
- Rules are tested against synthetic or lawfully obtained data.
- Rules are defensive. Do not add content whose purpose is to help bypass detection.
