# tools

Small defensive utilities, each with its own README.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
