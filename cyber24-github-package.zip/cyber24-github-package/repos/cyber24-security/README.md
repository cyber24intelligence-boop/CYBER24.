<div align="center">

# cyber24-security

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-security/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-security/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Defensive security engineering: hardening guidance, detection engineering, and secure-development practices.

## In scope

- Defensive modules and detection logic with tests
- Hardening baselines and checklists
- Secure-coding guidance
- Security policy documents

## Out of scope

- Exploit development or weaponised proof-of-concept code
- Malware, credential theft, or evasion tooling
- Anything intended for use against systems without authorisation

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `pyproject.toml` | Python packaging, test, and lint configuration. |
| `src/cyber24_security/detection/` | Detection logic (reserved namespace; empty). |
| `src/cyber24_security/hardening/` | Hardening checks (reserved namespace; empty). |
| `detections/` | Detection rules and authoring guidelines. |
| `hardening/` | Hardening baselines and checklists. |
| `secure-coding/` | Secure-coding standards and review checklists. |
| `policies/` | Security policy drafts. |
| `tools/` | Small defensive utilities, each with its own README. |
| `tests/` | Automated tests. |
| `docs/` | Repository documentation. |

## Getting started

Requires Python 3.11 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
