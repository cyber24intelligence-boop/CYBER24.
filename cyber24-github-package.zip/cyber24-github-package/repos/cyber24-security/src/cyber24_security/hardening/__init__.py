"""Hardening checks (reserved namespace; empty)."""
