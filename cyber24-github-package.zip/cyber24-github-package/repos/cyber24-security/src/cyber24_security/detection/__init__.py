"""Detection logic (reserved namespace; empty)."""
