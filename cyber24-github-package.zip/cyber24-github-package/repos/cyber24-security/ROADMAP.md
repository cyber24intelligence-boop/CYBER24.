# CYBER24 Security Engineering Roadmap

This roadmap is a statement of intent for an early-stage project. Items are planned, not promised, and may change. Nothing is marked done until it is implemented, tested, and merged.

## Phase 0: Foundation

- [ ] Repository scaffold and CI
- [ ] Defensive-only scope statement

## Phase 1: Standards

- [ ] Secure-coding guidelines
- [ ] Detection-rule authoring guide
- [ ] Review checklist

## Phase 2: First module

- [ ] Implement one narrow defensive module
- [ ] Tests and documentation
- [ ] Internal security review

## Phase 3: Hardening content

- [ ] First hardening baseline draft
- [ ] Peer review

## How this roadmap is tracked

Work is tracked through issues, milestones, and the organization project board. See the organization `.github` repository for labels and milestone definitions.
