import cyber24_security


def test_package_exposes_version():
    assert isinstance(cyber24_security.__version__, str)
