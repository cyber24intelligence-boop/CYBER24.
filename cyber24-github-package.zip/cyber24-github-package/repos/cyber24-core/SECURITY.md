# Security Policy

## Project status

cyber24-core is in early-stage development. No release has been audited, and
nothing in this repository should be treated as production-ready security
software.

## Reporting a vulnerability

Please report suspected vulnerabilities **privately**:

1. Use GitHub's private reporting: open the **Security** tab of this
   repository and choose **Report a vulnerability**.
2. If that is unavailable, email <security@YOUR-DOMAIN.example> with the subject
   `[SECURITY] cyber24-core`.

Do not open public issues, pull requests, or discussions for vulnerabilities.

Please include a description, affected files or versions, reproduction steps,
and your assessment of impact. Do not include real credentials or personal
data.

## What to expect

- Acknowledgement of your report within 7 days (target).
- An initial assessment and a plan or request for more information afterwards.
- Credit in the advisory if you want it, once a fix is available.

These are good-faith targets for a small early-stage project, not contractual
guarantees.

## Supported versions

Until a first tagged release exists, only the `main` branch is considered
supported.

## Safe-harbour intent

We will not pursue action against people who make a good-faith effort to follow
this policy, avoid privacy violations and service disruption, and give us
reasonable time to respond before any disclosure. Testing is limited to your
own installations of this code; never test against systems you do not own or
have written permission to test.

## Security practices for contributors

- Never commit secrets, tokens, keys, or real personal data.
- Keep dependencies minimal and review additions.
- Follow the [security principles](https://github.com/CYBER24/cyber24-docs/blob/main/docs/security-principles.md).
