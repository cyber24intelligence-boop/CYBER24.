"""Shared utilities (reserved namespace; empty)."""
