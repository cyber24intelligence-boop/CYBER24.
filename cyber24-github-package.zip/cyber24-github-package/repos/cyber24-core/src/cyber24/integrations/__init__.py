"""Adapters to external systems (reserved namespace; empty)."""
