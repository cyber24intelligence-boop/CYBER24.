"""CYBER24 Core. Early-stage scaffold; no features are implemented yet."""

__version__ = "0.0.0"
