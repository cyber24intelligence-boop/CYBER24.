"""Core platform services (reserved namespace; empty)."""
