# CYBER24 Core Roadmap

This roadmap is a statement of intent for an early-stage project. Items are planned, not promised, and may change. Nothing is marked done until it is implemented, tested, and merged.

## Phase 0: Foundation

- [ ] Repository scaffold, community files, CI
- [ ] Package skeleton with a passing smoke test

## Phase 1: Architecture

- [ ] Draft architecture decision records
- [ ] Define module boundaries and interfaces
- [ ] Choose first prototype target

## Phase 2: First prototype

- [ ] Implement and test one narrow prototype
- [ ] Write usage documentation for it
- [ ] Internal review

## Phase 3: Preview

- [ ] Stabilise public interfaces
- [ ] Security review before any public release
- [ ] Tag first pre-release

## How this roadmap is tracked

Work is tracked through issues, milestones, and the organization project board. See the organization `.github` repository for labels and milestone definitions.
