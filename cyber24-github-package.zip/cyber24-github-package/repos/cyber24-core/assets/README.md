# assets

Static assets such as diagrams and brand files.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
