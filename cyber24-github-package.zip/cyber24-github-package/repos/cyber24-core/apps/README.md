# apps

Application entry points and scaffolds.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
