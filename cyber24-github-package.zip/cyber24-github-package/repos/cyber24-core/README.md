<div align="center">

# cyber24-core

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-core/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-core/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Foundation codebase for CYBER24: shared libraries, application scaffolding, and integration points other repositories may build on.

## In scope

- Shared Python libraries and conventions
- Application scaffolding and prototypes
- Test strategy and CI standards
- Developer tooling

## Out of scope

- Offensive tooling of any kind
- Features described before they are implemented and tested

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `pyproject.toml` | Python packaging, test, and lint configuration. |
| `src/cyber24/common/` | Shared utilities (reserved namespace; empty). |
| `src/cyber24/platform/` | Core platform services (reserved namespace; empty). |
| `src/cyber24/integrations/` | Adapters to external systems (reserved namespace; empty). |
| `apps/` | Application entry points and scaffolds. |
| `prototypes/` | Time-boxed experiments. Not production code; may be deleted. |
| `assets/` | Static assets such as diagrams and brand files. |
| `tests/` | Automated tests. `test_package.py` is the first real test. |
| `docs/` | Repository documentation and design notes. |
| `scripts/` | Developer and maintenance scripts. |

## Getting started

Requires Python 3.11 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
