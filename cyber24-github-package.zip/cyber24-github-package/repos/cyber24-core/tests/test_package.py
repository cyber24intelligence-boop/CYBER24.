import cyber24


def test_package_exposes_version():
    assert isinstance(cyber24.__version__, str)
