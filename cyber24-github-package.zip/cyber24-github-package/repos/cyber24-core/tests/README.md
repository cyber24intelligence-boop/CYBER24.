# tests

Automated tests. `test_package.py` is the first real test.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
