# CYBER24 Cloud Security Roadmap

This roadmap is a statement of intent for an early-stage project. Items are planned, not promised, and may change. Nothing is marked done until it is implemented, tested, and merged.

## Phase 0: Foundation

- [ ] Repository scaffold and CI

## Phase 1: Guidance

- [ ] Multi-cloud principles
- [ ] Review checklist v0
- [ ] Shared-responsibility summary

## Phase 2: Policy-as-code

- [ ] Select tooling
- [ ] First tested example policy

## Phase 3: Review

- [ ] Peer review of guidance against provider documentation

## How this roadmap is tracked

Work is tracked through issues, milestones, and the organization project board. See the organization `.github` repository for labels and milestone definitions.
