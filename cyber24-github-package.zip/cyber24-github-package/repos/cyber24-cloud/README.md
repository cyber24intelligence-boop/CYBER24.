<div align="center">

# cyber24-cloud

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-cloud/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-cloud/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Vendor-neutral research and guidance on securing cloud environments.

## In scope

- Cloud security guidance and review checklists
- Benchmarks and assessment methodology
- Policy-as-code examples (defensive)
- Shared-responsibility documentation

## Out of scope

- Tooling to attack or enumerate third-party cloud accounts
- Provider credentials of any kind

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `guidance/multi-cloud/` | Provider-neutral guidance. |
| `guidance/aws/` | AWS-specific notes. |
| `guidance/azure/` | Azure-specific notes. |
| `guidance/gcp/` | Google Cloud-specific notes. |
| `benchmarks/` | Assessment methodology and checklists. |
| `policy-as-code/` | Defensive policy examples. Each example is tested before listing. |
| `research/` | Research notes. |
| `templates/` | Review and report templates. |
| `docs/` | Repository documentation. |

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
