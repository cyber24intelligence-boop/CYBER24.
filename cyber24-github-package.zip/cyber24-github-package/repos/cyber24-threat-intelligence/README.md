<div align="center">

# cyber24-threat-intelligence

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/cyber24-threat-intelligence/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/cyber24-threat-intelligence/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Methods, schemas, and templates for structuring and analysing threat information from lawful sources.

## In scope

- Data schemas for indicators and reports
- Source-evaluation and confidence methodology
- Analysis methods and report templates
- Defensive response playbooks

## Out of scope

- Collecting data unlawfully or accessing systems without authorisation
- Storing personal data or real victim data in the repository
- Targeting or profiling individuals

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `pyproject.toml` | Python packaging, test, and lint configuration. |
| `src/cyber24_threat_intel/models/` | Data models (reserved namespace; empty). |
| `schemas/` | JSON schemas. `indicator.schema.json` is the first draft. |
| `sources/` | Source catalogue and source-evaluation guidance. |
| `analysis/` | Analysis methods and worked examples (synthetic data only). |
| `reports/templates/` | Report templates with handling markings. |
| `playbooks/` | Defensive response playbooks. |
| `tests/` | Automated tests. |
| `docs/` | Repository documentation. |

## Getting started

Requires Python 3.11 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
