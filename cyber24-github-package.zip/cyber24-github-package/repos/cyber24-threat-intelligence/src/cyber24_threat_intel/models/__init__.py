"""Data models (reserved namespace; empty)."""
