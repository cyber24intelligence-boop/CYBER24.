"""CYBER24 Threat Intelligence. Early-stage scaffold; no features are implemented yet."""

__version__ = "0.0.0"
