# sources

Guidance for evaluating threat information sources.

Record for each source: reliability, lawfulness of access, update frequency,
terms of use, and how confidence is assigned. Use only lawful sources and
respect handling markings (TLP).
