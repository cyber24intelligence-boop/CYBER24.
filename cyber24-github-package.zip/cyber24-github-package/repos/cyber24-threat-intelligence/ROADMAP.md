# CYBER24 Threat Intelligence Roadmap

This roadmap is a statement of intent for an early-stage project. Items are planned, not promised, and may change. Nothing is marked done until it is implemented, tested, and merged.

## Phase 0: Foundation

- [ ] Repository scaffold and CI
- [ ] Draft indicator schema (included, minimally tested)

## Phase 1: Methodology

- [ ] Source-evaluation criteria
- [ ] Confidence and handling-marking guidance
- [ ] Report template

## Phase 2: Tooling

- [ ] Schema validation tooling
- [ ] Synthetic example dataset
- [ ] Analysis worked examples

## Phase 3: Review

- [ ] Privacy and legal review of source policy

## How this roadmap is tracked

Work is tracked through issues, milestones, and the organization project board. See the organization `.github` repository for labels and milestone definitions.
