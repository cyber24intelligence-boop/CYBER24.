# schemas

JSON schemas. `indicator.schema.json` is the first draft.

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
