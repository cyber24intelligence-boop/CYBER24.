# analysis

Analysis methods and worked examples (synthetic data only).

This directory is a placeholder created by the repository scaffold. Add content here as work begins.
