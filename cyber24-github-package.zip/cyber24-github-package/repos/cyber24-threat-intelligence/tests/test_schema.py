import json
from pathlib import Path

SCHEMA = Path(__file__).resolve().parents[1] / "schemas" / "indicator.schema.json"


def test_indicator_schema_is_valid_json_with_required_fields():
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    assert schema["type"] == "object"
    for field in ("id", "type", "value", "confidence", "tlp", "source"):
        assert field in schema["required"]
        assert field in schema["properties"]
