import cyber24_threat_intel


def test_package_exposes_version():
    assert isinstance(cyber24_threat_intel.__version__, str)
