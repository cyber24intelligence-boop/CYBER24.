# Contributing to CYBER24 repositories

Thank you for your interest in CYBER24. This project is in early-stage
development, so processes may evolve. These guidelines apply to every
contribution.

## Ground rules

1. Read the [Code of Conduct](CODE_OF_CONDUCT.md) and the
   [acceptable-use policy](https://github.com/CYBER24/cyber24-docs/blob/main/docs/acceptable-use.md).
2. CYBER24 work is **defensive and research oriented**. Contributions that
   enable unauthorised access, malware, or harm to others will be declined.
3. Describe only what is implemented and tested. Do not claim features that do
   not exist yet.
4. Never include secrets, credentials, personal data, or proprietary data.

## Workflow

1. Open or find an issue describing the change.
2. Fork the repository (or create a branch if you are a maintainer).
3. Create a branch: `type/short-description`, for example `docs/clarify-roadmap`.
4. Make focused commits with clear messages (Conventional Commits recommended,
   for example `feat:`, `fix:`, `docs:`, `chore:`).
5. Open a pull request using the template. CI must pass.
6. Address review feedback. A maintainer merges once approved.

## Repository-specific setup

See each repository's CONTRIBUTING.md for setup details.

## Quality expectations

- Add or update tests for behaviour changes.
- Keep documentation in step with the code.
- Prefer small, reviewable pull requests.
- Markdown must pass the repository lint checks.

## Reporting problems

- Bugs and ideas: use the issue templates.
- Vulnerabilities: follow [SECURITY.md](SECURITY.md) and report privately.
