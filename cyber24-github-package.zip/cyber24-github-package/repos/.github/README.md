<div align="center">

# .github

**Intelligent Technology. Security-Driven Innovation.**

[![CI](https://github.com/CYBER24/.github/actions/workflows/ci.yml/badge.svg)](https://github.com/CYBER24/.github/actions/workflows/ci.yml) ![Status](https://img.shields.io/badge/status-early--development-lightgrey) ![Use](https://img.shields.io/badge/use-defensive%20%26%20research-black)

</div>

> **Status: early-stage development.** This repository is a scaffold. Nothing described as planned is implemented unless it is explicitly listed as implemented and covered by tests.

## Purpose

Organization profile, default community health files, issue and pull request templates, and workflow templates for all CYBER24 repositories.

## In scope

- Organization profile README
- Default community health files
- Workflow templates
- Labels, milestones, and project-board guidance

## Out of scope

- Project source code

## Repository structure

| Path | Purpose |
| --- | --- |
| `README.md` | This file. |
| `ROADMAP.md` | Development roadmap. |
| `CONTRIBUTING.md` | How to contribute. |
| `SECURITY.md` | Vulnerability reporting policy. |
| `CODE_OF_CONDUCT.md` | Community standards. |
| `.github/` | Issue and PR templates, CI workflow, Dependabot. |
| `profile/` | Organization profile README displayed on the org page. |
| `workflow-templates/` | Reusable CI workflow template for new repositories. |
| `project-management/` | Labels, milestones, and project-board recommendations. |

## Documentation

Organization-wide documentation lives in [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs).

## Contributing and security

Read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Report vulnerabilities privately, never in public issues.

## License

A license has not been chosen yet. Until one is added, all rights are reserved by the project owner. See the publishing guide for how to choose one.
