## Summary

<!-- What does this change and why? -->

## Type of change

- [ ] Bug fix
- [ ] New functionality
- [ ] Research / experiment
- [ ] Documentation
- [ ] Maintenance / CI

## Checklist

- [ ] I have read the contributing guidelines.
- [ ] Tests were added or updated, and they pass locally.
- [ ] Documentation was updated where behaviour changed.
- [ ] No secrets, credentials, personal data, or proprietary data are included.
- [ ] This change is consistent with the acceptable-use policy (defensive and research purposes only).
- [ ] Claims in docs describe only what is implemented and tested.

## Related issues

<!-- Closes #123 -->
