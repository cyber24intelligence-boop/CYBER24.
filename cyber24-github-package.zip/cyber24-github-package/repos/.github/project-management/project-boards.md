# Project Board Recommendations

Use one organization-level GitHub Project so work across repositories is visible
in one place. Create it under the organization's **Projects** tab.

## Board: "CYBER24 Roadmap"

| Column (Status field) | Meaning |
| --- | --- |
| Backlog | Accepted ideas, not yet scheduled |
| Ready | Defined and ready to start |
| In progress | Actively being worked on |
| In review | Pull request open or review under way |
| Done | Merged or completed |

## Suggested fields

- **Division**: single select (six divisions).
- **Priority**: p0 to p3.
- **Milestone**: use the repository milestones.
- **Type**: bug, feature, research, documentation, maintenance.

## Suggested views

1. **Board** grouped by Status.
2. **Roadmap** timeline grouped by Milestone.
3. **By division** table grouped by Division.
4. **Research tracker** filtered to `type: research`, with the `needs: reproduction` label visible.

## Automation

Enable the built-in project workflows: auto-add new issues and pull requests
from the CYBER24 repositories, set status to Done when closed or merged.

## Security triage

Vulnerability reports must stay private. Handle them through each repository's
private security advisories, not on the public board.
