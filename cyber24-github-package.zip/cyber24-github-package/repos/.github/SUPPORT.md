# Support

CYBER24 is in early-stage development. There is no guaranteed support service.

- Questions and ideas: open a GitHub Discussion in the relevant repository,
  if Discussions are enabled, or an issue using the appropriate template.
- Bugs: open an issue using the bug report template.
- Security vulnerabilities: follow the [security policy](SECURITY.md). Do not
  open public issues.
