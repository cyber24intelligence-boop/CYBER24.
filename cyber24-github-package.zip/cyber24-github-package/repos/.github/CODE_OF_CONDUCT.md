# Code of Conduct

## Our commitment

CYBER24 is a professional engineering and research project. We want
participation to be respectful, constructive, and free of harassment for
everyone, regardless of background, identity, experience level, or location.

## Expected behaviour

- Be respectful and assume good faith.
- Give and accept technical feedback constructively.
- Credit other people's work and ideas.
- Keep discussions focused on the project.
- Respect privacy: never share other people's personal information.

## Unacceptable behaviour

- Harassment, discrimination, threats, or personal attacks.
- Sexualised language or unwelcome attention.
- Publishing private information without consent.
- Trolling or sustained disruption of discussions.
- Using project spaces to plan or promote unauthorised access to systems,
  malware, or any activity prohibited by our acceptable-use policy.

## Enforcement

Project maintainers are responsible for clarifying and enforcing these
standards. They may edit, remove, or reject contributions and may temporarily
or permanently restrict participation for behaviour they judge inappropriate.

## Reporting

Report concerns privately to <security@YOUR-DOMAIN.example>. Reports are handled
confidentially, and retaliation against reporters is not tolerated.

## Scope

This policy applies to all CYBER24 repositories, issues, pull requests,
discussions, and any space where someone represents the project.
