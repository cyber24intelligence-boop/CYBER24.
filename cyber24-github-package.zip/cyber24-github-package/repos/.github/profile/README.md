<div align="center">

# CYBER24

**Intelligent Technology. Security-Driven Innovation.**

![Stage](https://img.shields.io/badge/stage-early--development-lightgrey)
![Focus](https://img.shields.io/badge/focus-AI%20%26%20cybersecurity-black)
![Use](https://img.shields.io/badge/use-defensive%20%26%20research-2B2B2B)

</div>

CYBER24 is an early-stage enterprise technology initiative in artificial
intelligence and cybersecurity. We are building a rigorous, security-driven
foundation: defensive engineering, research, and documentation.

> **Honest status.** CYBER24 is in early development and founder-led. The
> repositories are scaffolds. We describe features as available only after they
> are implemented and tested.

## Mission and vision

**Mission:** research and build intelligent, security-driven technology that
helps defenders, with rigorous engineering and honest reporting.

**Vision:** a trusted enterprise-grade organisation where AI and security
engineering reinforce each other, with every claim backed by tested work.

## Technology divisions

| Division | Focus | Repository |
| --- | --- | --- |
| AI Research | Studies how machine learning can support defensive security, and how AI systems themselves can be secured and evaluated. | [`cyber24-ai-research`](https://github.com/CYBER24/cyber24-ai-research) |
| Security Engineering | Builds defensive security tooling, hardening guidance, and secure engineering practices. | [`cyber24-security`](https://github.com/CYBER24/cyber24-security) |
| Threat Intelligence | Develops methods for collecting, structuring, and analysing threat information from lawful sources. | [`cyber24-threat-intelligence`](https://github.com/CYBER24/cyber24-threat-intelligence) |
| Cloud Security | Researches and documents secure cloud architecture, configuration, and monitoring. | [`cyber24-cloud`](https://github.com/CYBER24/cyber24-cloud) |
| Software Engineering | Owns the shared codebase, application scaffolding, testing standards, and CI. | [`cyber24-core`](https://github.com/CYBER24/cyber24-core) |
| Research & Documentation | Owns written knowledge: architecture, policies, research strategy, and public documentation. | [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs) |

Divisions describe areas of responsibility. They are not yet staffed beyond the
founder, and we do not list members until real people have accepted roles.

## Development philosophy

- Security by design, from the first commit.
- Small, tested, documented, maintainable modules.
- Defensive purpose only, under our [acceptable-use policy](https://github.com/CYBER24/cyber24-docs/blob/main/docs/acceptable-use.md).
- Honest claims: planned is labelled planned.

## Research areas (under consideration)

- Machine learning for defensive detection
- Security and robustness of AI systems
- Threat-intelligence structuring and analysis
- Cloud security review and benchmarking
- Secure software engineering practices

## Roadmap

- **Phase 0 - Foundation** (Planned): Publish organization and repositories; establish ci, policies, and documentation baseline
- **Phase 1 - Architecture and research baseline** (Planned): Record architecture decisions; select first research questions; define evaluation and testing standards
- **Phase 2 - First prototypes** (Planned): One narrow, tested prototype per active division; internal review
- **Phase 3 - Preview** (Planned): Security review; first pre-release of selected components; gather external feedback

Full details: [roadmap](https://github.com/CYBER24/cyber24-docs/blob/main/docs/roadmap.md).

## Repositories

| Repository | Description |
| --- | --- |
| [`cyber24-core`](https://github.com/CYBER24/cyber24-core) | Foundation codebase for CYBER24: shared libraries, application scaffolding, and integration points other repositories may build on. |
| [`cyber24-ai-research`](https://github.com/CYBER24/cyber24-ai-research) | Research workspace for applying and securing AI in a cybersecurity context, with emphasis on reproducibility and honest reporting. |
| [`cyber24-security`](https://github.com/CYBER24/cyber24-security) | Defensive security engineering: hardening guidance, detection engineering, and secure-development practices. |
| [`cyber24-threat-intelligence`](https://github.com/CYBER24/cyber24-threat-intelligence) | Methods, schemas, and templates for structuring and analysing threat information from lawful sources. |
| [`cyber24-cloud`](https://github.com/CYBER24/cyber24-cloud) | Vendor-neutral research and guidance on securing cloud environments. |
| [`cyber24-docs`](https://github.com/CYBER24/cyber24-docs) | Central documentation for CYBER24: overview, architecture, policies, research strategy, and brand guidelines. |

## Collaboration

Interested in contributing? Read the contributing guidelines, check open
issues, and open an issue or discussion before large changes. Security
researchers: please report vulnerabilities privately through each repository's
Security tab.

## Founder

**Rishan**, Founder & Project Lead.
